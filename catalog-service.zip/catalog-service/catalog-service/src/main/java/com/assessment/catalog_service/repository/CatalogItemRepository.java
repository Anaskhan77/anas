package com.assessment.catalog_service.repository;


import com.assessment.catalog_service.model.CatalogItem;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import java.util.List;

public interface CatalogItemRepository extends MongoRepository<CatalogItem, String> {
    List<CatalogItem> findByNameContaining(String name);

    @Query("{ 'price' : { $gte: ?0, $lte: ?1 } }")
    List<CatalogItem> findByPriceBetween(double minPrice, double maxPrice);

    @Query("{ 'active': true }")
    List<CatalogItem> findAllActive();
}






