package com.assessment.catalog_service.controller;
import com.assessment.catalog_service.model.CatalogItem;
import com.assessment.catalog_service.repository.CatalogItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

        import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/catalog")
public class CatalogItemController {

    @Autowired
    private CatalogItemRepository catalogItemRepository;

    @GetMapping("/items")
    public List<CatalogItem> getAllItems() {
        return catalogItemRepository.findAll();
    }

    @GetMapping("/items/{id}")
    public ResponseEntity<CatalogItem> getItemById(@PathVariable String id) {
        Optional<CatalogItem> item = catalogItemRepository.findById(id);
        return item.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/items")
    public CatalogItem createItem(@RequestBody CatalogItem item) {
        return catalogItemRepository.save(item);
    }

    @PutMapping("/items/{id}")
    public ResponseEntity<CatalogItem> updateItem(@PathVariable String id, @RequestBody CatalogItem itemDetails) {
        Optional<CatalogItem> item = catalogItemRepository.findById(id);
        if (item.isPresent()) {
            CatalogItem updatedItem = item.get();
            updatedItem.setName(itemDetails.getName());
            updatedItem.setDescription(itemDetails.getDescription());
            updatedItem.setPrice(itemDetails.getPrice());
            return ResponseEntity.ok(catalogItemRepository.save(updatedItem));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/items/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable String id) {
        catalogItemRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
    @DeleteMapping("/items1/{id}")
    public void softDeleteItem(@PathVariable String id) {
        catalogItemRepository.findById(id).ifPresent(item -> {
            item.setActive(false);
            catalogItemRepository.save(item);
        });
    }


    @GetMapping("/items/search")
    public List<CatalogItem> searchItems(@RequestParam(required = false) String name,
                                         @RequestParam(required = false) Double minPrice,
                                         @RequestParam(required = false) Double maxPrice) {
        if (name != null) {
            return catalogItemRepository.findByNameContaining(name);
        } else if (minPrice != null && maxPrice != null) {
            return catalogItemRepository.findByPriceBetween(minPrice, maxPrice);
        } else {
            return catalogItemRepository.findAll();
        }
    }


}

